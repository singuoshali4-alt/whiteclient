package com.whitemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.item.Item;

@Mod.EventBusSubscriber(modid = WhiteMod.MODID)
public class ModItems {

    public static ItemWhiteSword WHITE_SWORD;

    public static void register() {
        WHITE_SWORD = new ItemWhiteSword();
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(WHITE_SWORD);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(
            WHITE_SWORD, 0,
            new ModelResourceLocation(WhiteMod.MODID + ":white_sword", "inventory")
        );
    }
}

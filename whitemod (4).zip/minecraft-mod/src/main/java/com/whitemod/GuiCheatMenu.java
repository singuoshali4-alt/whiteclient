package com.whitemod;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class GuiCheatMenu extends GuiScreen {

    @Override
    public void initGui() {
        int centerX = width / 2;
        int startY = height / 2 - 80;

        buttonList.add(new GuiButton(0, centerX - 75, startY,      150, 20, getLabel("Fly",         ModModules.fly)));
        buttonList.add(new GuiButton(1, centerX - 75, startY + 25, 150, 20, getLabel("Speed",       ModModules.speed)));
        buttonList.add(new GuiButton(2, centerX - 75, startY + 50, 150, 20, getLabel("NoFall",      ModModules.nofall)));
        buttonList.add(new GuiButton(3, centerX - 75, startY + 75, 150, 20, getLabel("FullBright",  ModModules.fullbright)));
        buttonList.add(new GuiButton(4, centerX - 75, startY + 100, 150, 20, getLabel("Jesus",      ModModules.jesus)));
        buttonList.add(new GuiButton(5, centerX - 75, startY + 130, 150, 20, "§cЗакрыть [F]"));
    }

    private String getLabel(String name, boolean enabled) {
        return (enabled ? "§a[ON]  " : "§c[OFF] ") + "§f" + name;
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: ModModules.fly        = !ModModules.fly;        break;
            case 1: ModModules.speed      = !ModModules.speed;      break;
            case 2: ModModules.nofall     = !ModModules.nofall;     break;
            case 3: ModModules.fullbright = !ModModules.fullbright; break;
            case 4: ModModules.jesus      = !ModModules.jesus;      break;
            case 5: mc.displayGuiScreen(null); return;
        }
        initGui();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawRect(width/2 - 90, height/2 - 95, width/2 + 90, height/2 + 60, 0xCC000000);

        drawCenteredString(fontRenderer, "§bWhiteClient §7v1.0", width/2, height/2 - 88, 0xFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

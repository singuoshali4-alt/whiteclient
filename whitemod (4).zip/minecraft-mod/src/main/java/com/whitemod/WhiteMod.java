package com.whitemod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = WhiteMod.MODID, name = WhiteMod.NAME, version = WhiteMod.VERSION, clientSideOnly = true)
public class WhiteMod {

    public static final String MODID   = "whitemod";
    public static final String NAME    = "WhiteClient";
    public static final String VERSION = "1.0.0";

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.register();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
    }
}

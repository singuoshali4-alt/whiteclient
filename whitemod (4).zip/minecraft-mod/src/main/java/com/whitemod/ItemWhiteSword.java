package com.whitemod;

import net.minecraft.item.ItemSword;

public class ItemWhiteSword extends ItemSword {

    public ItemWhiteSword() {
        super(ToolMaterial.IRON);
        setRegistryName("white_sword");
        setUnlocalizedName("white_sword");
        setMaxDamage(500);
        setCreativeTab(net.minecraft.creativetab.CreativeTabs.COMBAT);
    }
}

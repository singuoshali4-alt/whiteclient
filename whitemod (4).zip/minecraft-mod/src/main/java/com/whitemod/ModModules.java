package com.whitemod;

public class ModModules {
    public static boolean fly        = false;
    public static boolean speed      = false;
    public static boolean nofall     = false;
    public static boolean fullbright = false;
    public static boolean jesus      = false;
}

package com.whitemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = WhiteMod.MODID)
public class ClientEventHandler {

    private static boolean wasPressed = false;

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null) return;

        boolean isPressed = Keyboard.isKeyDown(Keyboard.KEY_F);
        if (isPressed && !wasPressed && mc.currentScreen == null) {
            mc.displayGuiScreen(new GuiCheatMenu());
        }
        wasPressed = isPressed;

        EntityPlayerSP player = mc.player;

        if (ModModules.nofall) {
            player.fallDistance = 0;
        }

        if (ModModules.fly) {
            player.capabilities.allowFlying = true;
            player.capabilities.isFlying = true;
        } else {
            if (player.capabilities.allowFlying && !mc.playerController.isSpectator()) {
                player.capabilities.allowFlying = false;
                player.capabilities.isFlying = false;
            }
        }

        if (ModModules.speed) {
            player.capabilities.setPlayerWalkSpeed(0.2f);
        } else {
            player.capabilities.setPlayerWalkSpeed(0.1f);
        }

        if (ModModules.fullbright) {
            mc.gameSettings.gammaSetting = 10.0f;
        }

        if (ModModules.jesus) {
            if (!player.isOnGround() && player.isInWater()) {
                player.motionY = 0.1;
            }
        }
    }
}
